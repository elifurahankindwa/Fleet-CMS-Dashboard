<?php
header('Content-Type: application/json');

// Database configuration
$host = 'localhost';
$dbname = 'cms1';
$username = 'root';
$password = '0707003999@@Admini';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get client ID from request or use a default
    $clientID = isset($_GET['clientID']) ? $_GET['clientID'] : 67;
    
    // Pagination parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $offset = ($page - 1) * $limit;

    // Search parameter
    $searchTerm = isset($_GET['search']) ? '%' . $_GET['search'] . '%' : '';

    // Base WHERE clause
    $whereClause = "WHERE clientID = :clientID";
    if (!empty($_GET['search'])) {
        $whereClause .= " AND (dID LIKE :search OR plateNo LIKE :search OR simID LIKE :search OR provider LIKE :search)";
    }

    // Get total number of records for pagination
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total 
        FROM fleet_view 
        $whereClause
    ");
    $stmt->bindParam(':clientID', $clientID);
    if (!empty($_GET['search'])) {
        $stmt->bindParam(':search', $searchTerm);
    }
    $stmt->execute();
    $total = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

    // Fetch paginated fleet data with search filter
    $stmt = $pdo->prepare("
        SELECT dID, plateNo, simID, provider 
        FROM fleet_view 
        $whereClause
        LIMIT :limit OFFSET :offset
    ");
    $stmt->bindParam(':clientID', $clientID);
    if (!empty($_GET['search'])) {
        $stmt->bindParam(':search', $searchTerm);
    }
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $fleetData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format provider values for display
    foreach ($fleetData as &$row) {
        if ($row['provider'] === 'h') {
            $row['provider'] = 'Halotel';
        } elseif ($row['provider'] === 'A') {
            $row['provider'] = 'Airtel';
        }
    }
    
    echo json_encode(['fleetData' => $fleetData, 'totalRecords' => $total, 'limit' => $limit]);
    
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
