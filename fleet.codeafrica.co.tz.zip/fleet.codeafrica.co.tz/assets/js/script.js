let dataModal;

window.myCharts = {};

document.addEventListener('DOMContentLoaded', function() {
    dataModal = new bootstrap.Modal(document.getElementById('dataModal'));
    loadDashboard();
    setupNavigation();
    initializeMap();
    setupGlobalSearch();
});

function setupNavigation() {
    const navLinks = document.querySelectorAll('.header-nav-menu a');
    const hamburgerMenu = document.getElementById('hamburgerMenu');
    const headerNavMenu = document.getElementById('headerNavMenu');
    const refreshBtn = document.getElementById('refreshBtn');
    const searchContainer = document.getElementById('searchContainer');

    hamburgerMenu.addEventListener('click', function() {
        headerNavMenu.classList.toggle('show');
    });

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            
            const table = this.getAttribute('data-table');
            document.getElementById('page-title').textContent = this.textContent.trim();
            
            if (table === 'dashboard') {
                document.getElementById('dashboard-content').style.display = 'block';
                document.getElementById('table-content').style.display = 'none';
                if (searchContainer) searchContainer.style.display = 'none';
                loadDashboard();
            } else {
                document.getElementById('dashboard-content').style.display = 'none';
                document.getElementById('table-content').style.display = 'block';
                if (searchContainer) searchContainer.style.display = 'block';
                
                const globalSearchInput = document.getElementById('globalSearch');
                if (globalSearchInput) globalSearchInput.value = '';
                
                loadTable(table, 1, 10, '');
            }

            if (headerNavMenu.classList.contains('show')) {
                headerNavMenu.classList.remove('show');
            }
        });
    });

    refreshBtn.addEventListener('click', refreshCurrentView);
    document.getElementById('saveData').addEventListener('click', saveData);
}

function setupGlobalSearch() {
    const globalSearchInput = document.getElementById('globalSearch');
    if (globalSearchInput) {
        let searchTimeout;
        
        globalSearchInput.addEventListener('input', () => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                const activeLink = document.querySelector('.header-nav-menu a.active');
                if (activeLink && activeLink.getAttribute('data-table') !== 'dashboard') {
                    const tableName = activeLink.getAttribute('data-table');
                    loadTable(tableName, 1, 10, globalSearchInput.value);
                }
            }, 300);
        });
        
        globalSearchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const activeLink = document.querySelector('.header-nav-menu a.active');
                if (activeLink && activeLink.getAttribute('data-table') !== 'dashboard') {
                    const tableName = activeLink.getAttribute('data-table');
                    loadTable(tableName, 1, 10, globalSearchInput.value);
                }
            }
        });
    }
}

function showLoader() {
    document.getElementById('loader-overlay').style.display = 'flex';
}

function hideLoader() {
    document.getElementById('loader-overlay').style.display = 'none';
}

function refreshCurrentView() {
    const activeLink = document.querySelector('.header-nav-menu a.active');
    if (!activeLink) {
        loadDashboard();
        showSuccessToast('Dashboard refreshed!');
        return;
    }
    
    const tableName = activeLink.getAttribute('data-table');
    if (tableName === 'dashboard') {
        loadDashboard();
        showSuccessToast('Dashboard refreshed!');
    } else {
        const globalSearchInput = document.getElementById('globalSearch');
        const searchQuery = globalSearchInput ? globalSearchInput.value : '';
        const currentPageBtn = document.querySelector('.pagination button.active');
        const currentPage = currentPageBtn ? currentPageBtn.getAttribute('data-page') : 1;
        
        loadTable(tableName, currentPage, 10, searchQuery);
        showSuccessToast(`${getTableDisplayName(tableName)} table refreshed!`);
    }
}

function showSuccessToast(message) {
    Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: message,
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true
    });
}

function showErrorToast(message) {
    Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'error',
        title: message,
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true
    });
}

function loadDashboard() {
    showLoader();
    
    const fetchCounts = fetch('../api/index.php?action=get_counts')
        .then(response => response.json())
        .then(data => {
            document.getElementById('client-count').textContent = data.client_count || 0;
            document.getElementById('device-count').textContent = data.device_count || 0;
            document.getElementById('fleet-count').textContent = data.fleet_count || 0;
        })
        .catch(error => showErrorToast('Error fetching dashboard counts.'));

    fetchDataAndRenderCharts();
    loadClientLocations();

    Promise.all([fetchCounts]).finally(() => {
        hideLoader();
    });
}

function loadTable(tableName, page = 1, limit = 10, searchQuery = '') {
    showLoader();
    
    const endpoint = tableName === 'fleet_view' ? 'get_fleet_view' : 'get_table';
    
    fetch(`../api/index.php?action=${endpoint}&table=${tableName}&page=${page}&limit=${limit}&search=${encodeURIComponent(searchQuery)}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                renderTable(tableName, data, searchQuery);
            } else {
                document.getElementById('table-container').innerHTML = `<div class="p-4"><p class="text-red-500">${data.message || 'Failed to load data.'}</p></div>`;
                showErrorToast(data.message);
            }
        })
        .catch(error => {
            document.getElementById('table-container').innerHTML = `<div class="p-4"><p class="text-red-500">Error loading table data.</p></div>`;
            showErrorToast('Error loading table data.');
        })
        .finally(() => {
            hideLoader();
        });
}

function renderTable(tableName, data, searchQuery) {
    const container = document.getElementById('table-container');
    const isView = data.isView || false;
    // For fleet_view, we use fleet_tbl as the base table for operations
    const baseTable = data.baseTable || tableName;

    if (!container.querySelector('.table-content-wrapper') || container.dataset.currentTable !== tableName) {
        const displayName = getTableDisplayName(tableName);
        container.innerHTML = `
            <div class="table-content-wrapper">
                <div class="flex flex-wrap justify-between items-center mb-6 gap-4">
                    <h2 class="text-2xl font-bold text-gray-800">${displayName}</h2>
                    ${!isView ? `<button id="addBtn" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition duration-300 flex items-center gap-2"><i class="fas fa-plus"></i> Add New</button>` : ''}
                </div>
                <div id="table-body"></div>
            </div>
        `;
        container.dataset.currentTable = tableName;
        container.dataset.baseTable = baseTable;
        if (!isView) {
            document.getElementById('addBtn').onclick = () => openAddModal(baseTable);
        }
    }
    
    const tableBody = document.getElementById('table-body');
    let recordsHtml = '';
    
    if (data.records.length > 0) {
        recordsHtml += '<div class="overflow-x-auto rounded-lg shadow-md"><table class="min-w-full bg-white border border-gray-200">';
        recordsHtml += '<thead class="bg-gray-200"><tr>';
        data.columns.forEach(column => {
            recordsHtml += `<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">${column}</th>`;
        });
        recordsHtml += '<th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Actions</th>';
        recordsHtml += '</tr></thead><tbody class="divide-y divide-gray-200">';
        
        data.records.forEach(row => {
            recordsHtml += '<tr class="bg-white hover:bg-gray-50 transition-colors duration-200">';
            data.columnNames.forEach(columnName => {
                recordsHtml += `<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${row[columnName] || ''}</td>`;
            });
            recordsHtml += `<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 flex gap-2">
                <button class="btn-edit bg-yellow-500 text-white px-3 py-1 rounded-lg hover:bg-yellow-600 transition duration-300" data-id="${row[data.primaryKey]}" data-table="${baseTable}"><i class="fas fa-edit"></i></button>
                <button class="btn-delete bg-red-500 text-white px-3 py-1 rounded-lg hover:bg-red-600 transition duration-300" data-id="${row[data.primaryKey]}" data-table="${baseTable}"><i class="fas fa-trash-alt"></i></button>
            </td>`;
            recordsHtml += '</tr>';
        });
        
        recordsHtml += '</tbody></table></div>';
        
        const currentPage = parseInt(data.currentPage);
        const totalPages = parseInt(data.totalPages);
        if (totalPages > 1) {
            recordsHtml += generatePaginationHTML(currentPage, totalPages);
        }

    } else {
        recordsHtml += `<div class="bg-white p-6 rounded-lg shadow-md text-center text-gray-500">No records found</div>`;
    }
    
    tableBody.innerHTML = recordsHtml;

    document.querySelectorAll('.btn-edit').forEach(btn => {
        btn.onclick = () => {
            const table = btn.getAttribute('data-table');
            const id = btn.getAttribute('data-id');
            openEditModal(table, id);
        };
    });
    
    document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.onclick = () => {
            const table = btn.getAttribute('data-table');
            const id = btn.getAttribute('data-id');
            showDeleteConfirmation(table, id, tableName);
        };
    });

    document.querySelectorAll('.pagination .page-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const parentLi = link.closest('.page-item');
            if (parentLi.classList.contains('disabled') || parentLi.classList.contains('active')) {
                return;
            }
            
            const page = link.getAttribute('data-page');
            if(page) {
                const globalSearchInput = document.getElementById('globalSearch');
                loadTable(tableName, page, 10, globalSearchInput.value);
            }
        });
    });
}

function showDeleteConfirmation(tableName, id, viewName = null) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            deleteRecord(tableName, id, viewName);
        }
    });
}

function openAddModal(tableName) {
    fetch(`../api/index.php?action=get_form&table=${tableName}`)
        .then(response => response.text())
        .then(html => {
            document.getElementById('modalTitle').textContent = `Add New ${getTableDisplayName(tableName)}`;
            document.getElementById('modalBody').innerHTML = html;
            document.getElementById('dataModal').setAttribute('data-current-table', tableName);
            document.getElementById('dataModal').removeAttribute('data-edit-id');
            dataModal.show();
            
            if (tableName === 'fleet_tbl') {
                $('#dataModal .select2').select2({
                    dropdownParent: $('#dataModal')
                });
            }
        })
        .catch(error => showErrorToast('Error loading form.'));
}

function openEditModal(tableName, id) {
    fetch(`../api/index.php?action=get_form&table=${tableName}&id=${id}`)
        .then(response => response.text())
        .then(html => {
            document.getElementById('modalTitle').textContent = `Edit ${getTableDisplayName(tableName)}`;
            document.getElementById('modalBody').innerHTML = html;
            document.getElementById('dataModal').setAttribute('data-current-table', tableName);
            document.getElementById('dataModal').setAttribute('data-edit-id', id);
            dataModal.show();

            if (tableName === 'fleet_tbl') {
                $('#dataModal .select2').select2({
                    dropdownParent: $('#dataModal')
                });
            }
        })
        .catch(error => showErrorToast('Error loading form.'));
}

function saveData() {
    const modalElement = document.getElementById('dataModal');
    const tableName = modalElement.getAttribute('data-current-table');
    const id = modalElement.getAttribute('data-edit-id');
    const form = document.getElementById('dataForm');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    const formData = new FormData(form);
    const action = id ? 'update_record' : 'add_record';
    let url = `../api/index.php?action=${action}&table=${tableName}`;
    if (id) url += `&id=${id}`;
    
    fetch(url, { method: 'POST', body: formData })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            dataModal.hide();
            const currentPageBtn = document.querySelector('.pagination button.active');
            const currentPage = currentPageBtn ? currentPageBtn.getAttribute('data-page') : 1;
            const globalSearchInput = document.getElementById('globalSearch');
            
            // Get the current view name from the active link
            const activeLink = document.querySelector('.header-nav-menu a.active');
            const currentView = activeLink ? activeLink.getAttribute('data-table') : tableName;
            
            loadTable(currentView, currentPage, 10, globalSearchInput.value);
            showSuccessToast(`${getTableDisplayName(tableName)} record saved successfully.`);
            
            if (['client_tbl', 'device_tbl', 'fleet_tbl', 'simcard_tbl'].includes(tableName)) {
                loadDashboard();
            }
        } else {
            showErrorToast(data.message || 'Error saving data');
        }
    })
    .catch(() => showErrorToast('An error occurred. Please try again.'));
}

function deleteRecord(tableName, id, viewName = null) {
    fetch(`../api/index.php?action=delete_record&table=${tableName}&id=${id}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const currentPageBtn = document.querySelector('.pagination button.active');
                let currentPage = currentPageBtn ? parseInt(currentPageBtn.getAttribute('data-page')) : 1;
                const recordsOnPage = document.querySelectorAll('#table-body tbody tr').length;
                if(recordsOnPage === 1 && currentPage > 1) currentPage--;

                const globalSearchInput = document.getElementById('globalSearch');
                // Reload the view, not the base table
                const tableToLoad = viewName || tableName;
                loadTable(tableToLoad, currentPage, 10, globalSearchInput.value);
                showSuccessToast(`${getTableDisplayName(tableName)} record deleted.`);
                
                if (['client_tbl', 'device_tbl', 'fleet_tbl', 'simcard_tbl'].includes(tableName)) {
                    loadDashboard();
                }
            } else {
                showErrorToast(data.message || 'Error deleting record');
            }
        })
        .catch(() => showErrorToast('An error occurred. Please try again.'));
}

function getTableDisplayName(tableName) {
    const names = {
        'client_tbl': 'Clients', 'device_tbl': 'Devices', 'fleet_tbl': 'Fleet',
        'fleet_view': 'Fleet View', 'simcard_tbl': 'SIM Cards',
        'service_tbl': 'Services', 'user_tbl': 'Users'
    };
    return names[tableName] || 'Records';
}

function generatePaginationHTML(currentPage, totalPages) {
    let paginationHtml = `<nav class="mt-6 flex justify-center"><ul class="pagination">`;
    const maxPagesToShow = 5;
    const halfPages = Math.floor(maxPagesToShow / 2);

    paginationHtml += `
        <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
            <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
        </li>`;

    let startPage = 1;
    let endPage = totalPages;

    if (totalPages > maxPagesToShow) {
        if (currentPage <= halfPages + 1) {
            startPage = 1;
            endPage = maxPagesToShow;
        } else if (currentPage >= totalPages - halfPages) {
            startPage = totalPages - maxPagesToShow + 1;
            endPage = totalPages;
        } else {
            startPage = currentPage - halfPages;
            endPage = currentPage + halfPages;
        }
    }
    
    if (startPage > 1) {
        paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li>`;
        if (startPage > 2) {
             paginationHtml += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
        }
    }

    for (let i = startPage; i <= endPage; i++) {
        paginationHtml += `
            <li class="page-item ${i === currentPage ? 'active' : ''}">
                <a class="page-link" href="#" data-page="${i}">${i}</a>
            </li>`;
    }

    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            paginationHtml += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
        }
        paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${totalPages}">${totalPages}</a></li>`;
    }

    paginationHtml += `
        <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
            <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
        </li>`;
    
    paginationHtml += '</ul></nav>';
    return paginationHtml;
}

async function fetchDataAndRenderCharts() {
    try {
        const response = await fetch('../api/index.php?chart=true');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();

        if (data.error) {
            throw new Error(data.error);
        }

        document.getElementById('totalVehicles').textContent = data.totalVehicles.total_vehicles || 0;
        document.getElementById('totalClients').textContent = data.totalClients.total_clients || 0;

        Object.values(window.myCharts).forEach(chart => chart.destroy());

        window.myCharts.vehiclesProvider = new Chart(document.getElementById('vehiclesProviderChart'), {
            type: 'pie', data: { labels: data.vehiclesProvider.map(r => r.provider), datasets: [{ data: data.vehiclesProvider.map(r => r.vehicle_count), backgroundColor: ['#3b82f6', '#10b981', '#f59e0b'] }] }, options: { responsive: true, plugins: { legend: { position: 'left' } } }
        });

        window.myCharts.vehiclesRegion = new Chart(document.getElementById('vehiclesRegionChart'), {
            type: 'doughnut', data: { labels: data.vehiclesRegion.map(r => r.region), datasets: [{ data: data.vehiclesRegion.map(r => r.vehicle_count), backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'] }] }, options: { responsive: true, plugins: { legend: { position: 'right' } } }
        });

        window.myCharts.costByProvider = new Chart(document.getElementById('costByProviderChart'), {
            type: 'bar', data: { labels: data.costByProvider.map(r => r.provider), datasets: [{ label: 'Total Cost', data: data.costByProvider.map(r => r.total_cost), backgroundColor: ['#ef4444', '#f97316'] }] }, options: { responsive: true, scales: { y: { beginAtZero: true } } }
        });

        window.myCharts.vehiclesByClient = new Chart(document.getElementById('vehiclesByClientChart'), {
            type: 'bar', data: { labels: data.vehiclesByClient.map(r => r.clientName), datasets: [{ label: 'Vehicles', data: data.vehiclesByClient.map(r => r.vehicle_count), backgroundColor: 'rgba(52, 152, 219, 0.8)' }] }, options: { responsive: true, indexAxis: 'y', scales: { x: { beginAtZero: true } } }
        });

    } catch (error) {
        console.error('Error fetching chart data:', error);
    }
}

let map;
let markers = [];
const regionCoordinates = {
    'Arusha': { lat: -3.3869, lon: 36.6829 }, 'Dar es salaam': { lat: -6.7924, lon: 39.2083 },
    'Dodoma': { lat: -6.1630, lon: 35.7516 }, 'Geita': { lat: -2.8752, lon: 32.2282 },
    'Iringa': { lat: -7.7700, lon: 35.6900 }, 'Kagera': { lat: -1.9500, lon: 31.2500 },
    'Katavi': { lat: -6.5000, lon: 31.0000 }, 'Kigoma': { lat: -4.8769, lon: 29.6269 },
    'Kilimanjaro': { lat: -3.3333, lon: 37.3500 }, 'Moshi': { lat: -3.3333, lon: 37.3500 },
    'Lindi': { lat: -10.0000, lon: 39.0000 }, 'Manyara': { lat: -4.7500, lon: 36.5000 },
    'Mara': { lat: -1.5000, lon: 34.0000 }, 'Mbeya': { lat: -8.9000, lon: 33.4500 },
    'Morogoro': { lat: -6.8235, lon: 37.6620 }, 'Mtwara': { lat: -10.2762, lon: 40.1818 },
    'Mwanza': { lat: -2.5162, lon: 32.9175 }, 'Njombe': { lat: -9.3333, lon: 34.7667 },
    'Pemba North': { lat: -5.0486, lon: 39.7610 }, 'Pemba South': { lat: -5.2500, lon: 39.7500 },
    'Pwani': { lat: -6.8000, lon: 39.0000 }, 'Rukwa': { lat: -8.0000, lon: 31.0000 },
    'Ruvuma': { lat: -10.7000, lon: 36.2667 }, 'Shinyanga': { lat: -3.6625, lon: 33.4242 },
    'Simiyu': { lat: -3.0000, lon: 34.0000 }, 'Singida': { lat: -4.8211, lon: 34.7479 },
    'Songwe': { lat: -8.3000, lon: 32.7833 }, 'Tabora': { lat: -5.0167, lon: 32.8333 },
    'Tanga': { lat: -5.0689, lon: 39.0983 }, 'Zanzibar': { lat: -5.9000, lon: 39.3000 },
    'Zanzibar North': { lat: -5.9000, lon: 39.3000 }, 'Zanzibar South': { lat: -6.2500, lon: 39.4167 },
    'Zanzibar West': { lat: -6.1659, lon: 39.1990 }
};

function initializeMap() {
    if (map) return;
    map = L.map('map').setView([-6.3690, 34.8888], 6);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);
    loadClientLocations();
}

function loadClientLocations() {
    fetch('../api/index.php?action=get_client_locations')
        .then(response => response.json())
        .then(data => {
            markers.forEach(marker => map.removeLayer(marker));
            markers = [];
            if (data.success && data.regions && data.regions.length > 0) {
                data.regions.forEach(regionData => {
                    const coords = regionCoordinates[regionData.region];
                    if (coords) {
                        const marker = L.marker([coords.lat, coords.lon]).addTo(map)
                            .bindPopup(`<h3 class="font-bold">${regionData.region}</h3>Clients: ${regionData.clientCount}<br>Vehicles: ${regionData.vehicleCount}`);
                        markers.push(marker);
                    }
                });
                if (markers.length > 0) {
                    const group = new L.featureGroup(markers);
                    map.fitBounds(group.getBounds().pad(0.1));
                }
            }
        })
        .catch(error => {
            console.error('Error loading map data:', error);
            showErrorToast('Could not load map data.');
        });
}