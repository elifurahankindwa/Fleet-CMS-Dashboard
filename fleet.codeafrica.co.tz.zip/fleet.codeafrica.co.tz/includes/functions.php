<?php
function getCount($conn, $table, $where = '') {
    $sql = "SELECT COUNT(*) as count FROM `$table` $where";
    $result = $conn->query($sql);
    return $result ? $result->fetch_assoc()['count'] : 0;
}

function getPrimaryKey($conn, $table) {
    $result = $conn->query("SHOW KEYS FROM `$table` WHERE Key_name = 'PRIMARY'");
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc()['Column_name'];
    }
    return null;
}

function getTableFields($conn, $table) {
    $fields = [];
    $result = $conn->query("DESCRIBE `$table`");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $fields[] = $row;
        }
    }
    return $fields;
}

function getClientDropdown($conn, $selected = '') {
    $html = '<select class="form-control" id="clientID" name="clientID" required>';
    $html .= '<option value="">Select Client</option>';
    
    $result = $conn->query("SELECT clientID, clientName, companyName FROM client_tbl");
    while ($row = $result->fetch_assoc()) {
        $sel = ($row['clientID'] == $selected) ? 'selected' : '';
        $html .= '<option value="' . $row['clientID'] . '" ' . $sel . '>' . 
                 htmlspecialchars($row['clientName'] . ' (' . $row['companyName'] . ')') . '</option>';
    }
    
    $html .= '</select>';
    return $html;
}

function getDeviceDropdown($conn, $selected = '') {
    $html = '<select class="form-control" id="dID" name="dID" required>';
    $html .= '<option value="">Select Device</option>';
    
    $result = $conn->query("SELECT dID, deviceName FROM device_tbl");
    while ($row = $result->fetch_assoc()) {
        $sel = ($row['dID'] == $selected) ? 'selected' : '';
        $html .= '<option value="' . $row['dID'] . '" ' . $sel . '>' . 
                 htmlspecialchars($row['deviceName']) . '</option>';
    }
    
    $html .= '</select>';
    return $html;
}

function getSimCardDropdown($conn, $selected = '') {
    $html = '<select class="form-control" id="simID" name="simID" required>';
    $html .= '<option value="">Select SIM Card</option>';
    
    $result = $conn->query("SELECT simID, provider, iccdNo FROM simcard_tbl");
    while ($row = $result->fetch_assoc()) {
        $sel = ($row['simID'] == $selected) ? 'selected' : '';
        $html .= '<option value="' . $row['simID'] . '" ' . $sel . '>' . 
                 htmlspecialchars($row['provider'] . ' (' . $row['iccdNo'] . ')') . '</option>';
    }
    
    $html .= '</select>';
    return $html;
}

function getServiceDropdown($conn, $selected = '') {
    $html = '<select class="form-control" id="sID" name="sID" required>';
    $html .= '<option value="">Select Service</option>';
    
    $result = $conn->query("SELECT sID, serviceName FROM service_tbl");
    while ($row = $result->fetch_assoc()) {
        $sel = ($row['sID'] == $selected) ? 'selected' : '';
        $html .= '<option value="' . $row['sID'] . '" ' . $sel . '>' . 
                 htmlspecialchars($row['serviceName']) . '</option>';
    }
    
    $html .= '</select>';
    return $html;
}
