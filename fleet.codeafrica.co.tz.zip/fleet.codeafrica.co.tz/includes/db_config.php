<?php

$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = '0707003999@@Admini';
$dbName = 'cms1';

$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);


if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

?>
