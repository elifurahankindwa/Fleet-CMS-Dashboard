<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: ../pages/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../favicon_io/favicon.ico">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
    
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="" />
    
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    
    <title>CMS Admin Dashboard</title>
</head>
<body>
    <div class="header-nav">
        <nav class="header-nav-menu" id="headerNavMenu">
            <ul>
                <li><a href="#" class="active" data-table="dashboard"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="#" data-table="fleet_view"><i class="fas fa-book"></i> Fleet View</a></li>
                <li><a href="#" data-table="client_tbl"><i class="fas fa-user-alt"></i> Clients</a></li>
                <li><a href="#" data-table="device_tbl"><i class="fas fa-mobile-alt"></i> Devices</a></li>
                <li><a href="#" data-table="fleet_tbl"><i class="fas fa-car"></i> Fleet</a></li>
                <li><a href="#" data-table="simcard_tbl"><i class="fas fa-sim-card"></i> SIM Cards</a></li>
                <li><a href="#" data-table="service_tbl"><i class="fas fa-cogs"></i> Services</a></li>
                <li><a href="#" data-table="user_tbl"><i class="fas fa-users"></i> Users</a></li>
                
            </ul>
        </nav>
        <div class="hamburger-menu" id="hamburgerMenu">
            <i class="fas fa-bars"></i>
        </div>
        <div class="user-info">
            
                    
           <div class="dropdown">
    <button class="btn dropdown-toggle access-features-btn" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false">
        <i class="fa-solid fa-universal-access me-2"></i> Access Features
    </button>
    <ul class="dropdown-menu dropdown-menu-end custom-dropdown-menu" aria-labelledby="dropdownMenuButton">
        <li>
            <a class="dropdown-item" href="../adminer-db/adminer.php" target="_blank">
                <i class="fa-solid fa-database me-2"></i> Database
            </a>
        </li>
        <li>
            <a class="dropdown-item" href="../pages/export.html">
                <i class="fa-solid fa-file-export me-2"></i> Export
            </a>
        </li>
        <li>
            <a class="dropdown-item" href="/fleet.codeafrica.co.tz/fleet_view.html" target="_blank">
                <i class="fas fa-paw me-2"></i> TS - Fleet View
            </a>
        </li>
        <li>
            <a class="dropdown-item" href="#" id="refreshBtn">
                <i class="fas fa-sync-alt me-2"></i> Refresh
            </a>
        </li>
        <li><hr class="dropdown-divider"></li>
        <li>
            <a class="dropdown-item logout-item" href="../pages/logout.php">
                <i class="fas fa-sign-out-alt me-2"></i> LOGOUT
            </a>
        </li>
    </ul>
</div>

        </div>
    </div>
    
    <div class="main-content">
        <div class="page-header">
            <h1 id="page-title">Dashboard</h1>
        </div>
        
        
        <div class="mb-6" id="searchContainer" style="display: none;">
            <div class="relative flex-grow">
                <input type="text" id="globalSearch" placeholder="Search..." class="w-full max-w-lg pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 text-gray-700">
                <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <svg class="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                    </svg>
                </div>
            </div>
        </div>
        
        <div id="dashboard-content">
            <div class="cards" id="dashboard-cards">
                <div class="card">
                    <h3>Total Clients</h3>
                    <p>All registered clients</p>
                    <div class="number" id="client-count">0</div>
                </div>
                <div class="card">
                    <h3>Total Devices</h3>
                    <p>All tracking devices</p>
                    <div class="number" id="device-count">0</div>
                </div>
                <div class="card">
                    <h3>Active Fleet</h3>
                    <p>Vehicles in fleet</p>
                    <div class="number" id="fleet-count">0</div>
                </div>
            </div>
            
            <div id="dashboard" class="container mx-auto">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div class="bg-white p-6 rounded-lg shadow-md flex items-center justify-between transition duration-300 ease-in-out hover:scale-105">
                        <div>
                            <p class="text-sm font-medium text-gray-500">Total Vehicles</p>
                            <p id="totalVehicles" class="text-3xl font-bold text-gray-900 mt-1">...</p>
                        </div>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 5.04A12.001 12.001 0 0012 21a12.001 12.001 0 008.618-12.956z" />
                        </svg>
                    </div>
                    <div class="bg-white p-6 rounded-lg shadow-md flex items-center justify-between transition duration-300 ease-in-out hover:scale-105">
                        <div>
                            <p class="text-sm font-medium text-gray-500">Total Clients</p>
                            <p id="totalClients" class="text-3xl font-bold text-gray-900 mt-1">...</p>
                        </div>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14v7m0 0H5m7 0h7" />
                        </svg>
                    </div>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
                    <div class="bg-white p-6 rounded-lg shadow-md">
                        <h2 class="text-lg font-semibold text-gray-700 mb-4">Vehicles by Provider</h2>
                        <canvas id="vehiclesProviderChart"></canvas>
                    </div>

                    <div class="bg-white p-6 rounded-lg shadow-md">
                        <h2 class="text-lg font-semibold text-gray-700 mb-4">Vehicles by Region</h2>
                        <canvas id="vehiclesRegionChart"></canvas>
                    </div>

                    <div class="bg-white p-6 rounded-lg shadow-md">
                        <h2 class="text-lg font-semibold text-gray-700 mb-4">Cost by Provider</h2>
                        <canvas id="costByProviderChart"></canvas>
                    </div>

                    <div class="bg-white p-6 rounded-lg shadow-md lg:col-span-2">
                        <h2 class="text-lg font-semibold text-gray-700 mb-4">Total Vehicles by Client</h2>
                        <canvas id="vehiclesByClientChart"></canvas>
                    </div>
                    
                    <div class="bg-white p-6 rounded-lg shadow-md lg:col-span-2">
                        <h2 class="text-lg font-semibold text-gray-700 mb-4">Client Locations Map</h2>
                        <div id="map" style="height: 500px; border-radius: 8px; width: 700px"></div>
                    </div>
                </div>
            </div>
        </div>

        <div id="table-content">
            <div id="table-container"></div>
        </div>
    </div>

    <div class="loader-overlay" id="loader-overlay">
        <div class="loader"></div>
    </div>
    
    
    <div class="modal fade" id="dataModal" tabindex="-1" aria-labelledby="dataModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">Add New Record</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="modalBody"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveData">Save</button>
                </div>
            </div>
        </div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    
    
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>

    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    
    <script src="../assets/js/script.js"></script>
</body>
</html>

