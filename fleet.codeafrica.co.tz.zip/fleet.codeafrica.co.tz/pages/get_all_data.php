<?php

ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);


header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');


require_once('../includes/db_config.php');


if (!isset($dbHost) || !isset($dbUser) || !isset($dbPass) || !isset($dbName)) {
    http_response_code(500);
    die(json_encode(['error' => 'Database configuration incomplete']));
}


$allowedTables = [
    'client_tbl' => ['clientID', 'clientName', 'companyName', 'phoneNo', 'email', 'region'],
    'fleet_tbl' => ['No', 'clientID', 'dID', 'simID', 'plateNo', 'cost', 'installDate', 'comment']
];

try {
    
    if (!isset($_GET['table']) || empty($_GET['table'])) {
        throw new Exception('No table specified');
    }

    $tableName = $_GET['table'];
    
    
    if (!array_key_exists($tableName, $allowedTables)) {
        throw new Exception('Invalid table name');
    }

    
    $columns = '*';
    if (isset($_GET['columns']) && !empty($_GET['columns'])) {
        $requestedColumns = explode(',', $_GET['columns']);
        $validColumns = array_intersect($requestedColumns, $allowedTables[$tableName]);
        
        if (!empty($validColumns)) {
            $columns = '`' . implode('`,`', $validColumns) . '`';
        }
    }

    
    $conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

    if ($conn->connect_error) {
        throw new Exception('Database connection failed');
    }

    
    $sql = "SELECT $columns FROM `$tableName`";
    $result = $conn->query($sql);

    if (!$result) {
        throw new Exception('Query failed: ' . $conn->error);
    }

    
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    $conn->close();
    
    
    echo json_encode($data);
    exit;

} catch (Exception $e) {
    http_response_code(500);
    die(json_encode(['error' => $e->getMessage()]));
}
?>