<?php
header('Content-Type: application/json');

// Database configuration
$host = 'localhost';
$dbname = 'cms1';
$username = 'root';
$password = '0707003999@@Admini';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get client ID from request or use a default
    $clientID = isset($_GET['clientID']) ? $_GET['clientID'] : 67;
    
    // Fetch client information
    $stmt = $pdo->prepare("SELECT * FROM client_tbl WHERE clientID = :clientID");
    $stmt->bindParam(':clientID', $clientID);
    $stmt->execute();
    $client = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$client) {
        echo json_encode(['error' => 'Client not found']);
        exit;
    }
    
    // Count total SIM cards
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total 
        FROM fleet_tbl 
        WHERE clientID = :clientID
    ");
    $stmt->bindParam(':clientID', $clientID);
    $stmt->execute();
    $totalSims = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Count H-SIM cards (provider = 'h')
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as hSims 
        FROM fleet_tbl f
        JOIN simcard_tbl s ON f.simID = s.simID
        WHERE f.clientID = :clientID AND s.provider = 'h'
    ");
    $stmt->bindParam(':clientID', $clientID);
    $stmt->execute();
    $hSims = $stmt->fetch(PDO::FETCH_ASSOC)['hSims'];
    
    // Count A-SIM cards (provider = 'A')
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as aSims 
        FROM fleet_tbl f
        JOIN simcard_tbl s ON f.simID = s.simID
        WHERE f.clientID = :clientID AND s.provider = 'A'
    ");
    $stmt->bindParam(':clientID', $clientID);
    $stmt->execute();
    $aSims = $stmt->fetch(PDO::FETCH_ASSOC)['aSims'];
    
    // Count active devices
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as activeDevices 
        FROM fleet_tbl f
        JOIN device_tbl d ON f.dID = d.dID
        WHERE f.clientID = :clientID AND d.status = 'active'
    ");
    $stmt->bindParam(':clientID', $clientID);
    $stmt->execute();
    $activeDevices = $stmt->fetch(PDO::FETCH_ASSOC)['activeDevices'];
    
    // Count inactive devices
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as inactiveDevices 
        FROM fleet_tbl f
        JOIN device_tbl d ON f.dID = d.dID
        WHERE f.clientID = :clientID AND d.status = 'inactive'
    ");
    $stmt->bindParam(':clientID', $clientID);
    $stmt->execute();
    $inactiveDevices = $stmt->fetch(PDO::FETCH_ASSOC)['inactiveDevices'];
    
    // Combine all data
    $response = array_merge($client, [
        'totalSims' => $totalSims,
        'hSims' => $hSims,
        'aSims' => $aSims,
        'activeDevices' => $activeDevices,
        'inactiveDevices' => $inactiveDevices
    ]);
    
    echo json_encode($response);
    
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>