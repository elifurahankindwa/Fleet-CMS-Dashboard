<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');


require_once __DIR__ . '/../includes/db_config.php';


if (isset($_GET['chart']) && $_GET['chart'] === 'true') {
    getChartData();
    exit;
}


if (isset($_GET['all_data']) && !empty($_GET['table'])) {
    getAllData();
    exit;
}


$action = $_GET['action'] ?? '';

if (!empty($action)) {
    $conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

    if ($conn->connect_error) {
        http_response_code(500);
        die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
    }

    switch ($action) {
        case 'get_counts':
            getCounts($conn);
            break;
        case 'get_table':
            getTable($conn, $_GET['table'], $_GET['page'] ?? 1, $_GET['limit'] ?? 10, $_GET['search'] ?? '');
            break;
        case 'get_fleet_view':
            getFleetView($conn, $_GET['page'] ?? 1, $_GET['limit'] ?? 10, $_GET['search'] ?? '');
            break;
        case 'get_form':
            getForm($conn, $_GET['table'], $_GET['id'] ?? null);
            break;
        case 'add_record':
            addRecord($conn, $_GET['table']);
            break;
        case 'update_record':
            updateRecord($conn, $_GET['table'], $_GET['id']);
            break;
        case 'delete_record':
            deleteRecord($conn, $_GET['table'], $_GET['id']);
            break;
        case 'get_chart_data':
            getChartDataAPI($conn);
            break;
        case 'get_client_locations':
            getRegionData($conn);
            break;
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            break;
    }

    $conn->close();
    exit;
}


echo json_encode(['success' => false, 'message' => 'No action specified']);



function getRegionData($conn) {
    $sql = "
        SELECT 
            c.region,
            COUNT(DISTINCT c.clientID) as clientCount,
            COUNT(f.No) as vehicleCount
        FROM 
            client_tbl c
        LEFT JOIN 
            fleet_tbl f ON c.clientID = f.clientID
        WHERE 
            c.region IS NOT NULL AND c.region != ''
        GROUP BY 
            c.region
        ORDER BY 
            c.region
    ";
    $result = $conn->query($sql);

    $locations = [];

    if ($result) {
        while($row = $result->fetch_assoc()) {
            $region = trim($row['region']);
            if (!empty($region)) {
                $locations[] = [
                    'region' => $region,
                    'clientCount' => (int)$row['clientCount'],
                    'vehicleCount' => (int)$row['vehicleCount']
                ];
            }
        }
        echo json_encode(['success' => true, 'regions' => $locations]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error fetching region data: ' . $conn->error]);
    }
}

function getCounts($conn) {
    $counts = [
        'client_count' => getCount($conn, 'client_tbl'),
        'device_count' => getCount($conn, 'device_tbl'),
        'fleet_count' => getCount($conn, 'fleet_tbl'),
        'sim_count' => getCount($conn, 'simcard_tbl', "WHERE status = 'Active'")
    ];
    
    echo json_encode($counts);
}

function getCount($conn, $table, $where = '') {
    $sql = "SELECT COUNT(*) as count FROM `$table` $where";
    $result = $conn->query($sql);
    if ($result) {
        $row = $result->fetch_assoc();
        return isset($row['count']) ? (int)$row['count'] : 0;
    }
    return 0;
}

function getTable($conn, $table, $page, $limit, $search) {
    $table = mysqli_real_escape_string($conn, $table);
    $page = (int)$page;
    $limit = (int)$limit;
    $search = mysqli_real_escape_string($conn, $search);
    
    $offset = ($page - 1) * $limit;
    
    $whereClause = '';
    if (!empty($search)) {
        $fields = getTableFields($conn, $table);
        $searchFields = [];
        foreach ($fields as $field) {
            $searchFields[] = "`" . $field['Field'] . "` LIKE '%" . $search . "%'";
        }
        $whereClause = " WHERE " . implode(' OR ', $searchFields);
    }

    $totalRecords = 0;
    $countSql = "SELECT COUNT(*) as count FROM `$table` $whereClause";
    $countResult = $conn->query($countSql);
    if ($countResult) {
        $totalRecords = $countResult->fetch_assoc()['count'];
    }
    
    $sql = "SELECT * FROM `$table` $whereClause LIMIT $limit OFFSET $offset";
    $result = $conn->query($sql);
    
    if (!$result) {
        echo json_encode(['success' => false, 'message' => 'Error loading table: ' . $conn->error]);
        return;
    }
    
    $columns = [];
    $columnNames = [];
    $fields = $result->fetch_fields();
    foreach ($fields as $field) {
        $columns[] = ucwords(str_replace('_', ' ', $field->name));
        $columnNames[] = $field->name;
    }
    
    $records = [];
    while ($row = $result->fetch_assoc()) {
        $records[] = $row;
    }
    
    $primaryKey = getPrimaryKey($conn, $table);
    
    $displayName = ucwords(str_replace('_', ' ', $table));
    
    $responseData = [
        'success' => true,
        'records' => $records,
        'columns' => $columns,
        'columnNames' => $columnNames,
        'primaryKey' => $primaryKey,
        'displayName' => $displayName,
        'totalRecords' => $totalRecords,
        'currentPage' => $page,
        'limit' => $limit,
        'totalPages' => ceil($totalRecords / $limit),
        'searchQuery' => $search
    ];
    
    echo json_encode($responseData);
}

function getTableFields($conn, $table) {
    $fields = [];
    $result = $conn->query("DESCRIBE `$table`");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $fields[] = $row;
        }
    }
    return $fields;
}

function getPrimaryKey($conn, $table) {
    $result = $conn->query("SHOW KEYS FROM `$table` WHERE Key_name = 'PRIMARY'");
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['Column_name'];
    }
    
    $fields = getTableFields($conn, $table);
    return !empty($fields) ? $fields[0]['Field'] : 'id';
}

function getForm($conn, $table, $id = null) {
    $fields = getTableFields($conn, $table);
    $values = [];
    
    if ($id) {
        $primaryKey = getPrimaryKey($conn, $table);
        $sql = "SELECT * FROM `$table` WHERE `$primaryKey` = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $values = $result->fetch_assoc();
        $stmt->close();
    }
    
    $html = '<form id="dataForm">';
    
    foreach ($fields as $field) {
        $fieldName = $field['Field'];
        $fieldType = strtolower($field['Type']);
        $required = ($field['Null'] === 'NO' && is_null($field['Default'])) ? 'required' : '';
        
        
        if (strpos($field['Extra'], 'auto_increment') !== false && !$id) {
            continue;
        }
        
        $html .= '<div class="mb-3">';
        $html .= '<label for="' . $fieldName . '" class="form-label">' . ucwords(str_replace('_', ' ', $fieldName)) . '</label>';
        
        $currentValue = $values[$fieldName] ?? '';
        
        
        if (strpos($fieldName, 'clientID') === 0 && $table !== 'client_tbl') {
            $html .= getClientDropdown($conn, $currentValue);
        } elseif (strpos($fieldName, 'dID') === 0 && $table !== 'device_tbl') {
            $html .= getDeviceDropdown($conn, $currentValue);
        } elseif (strpos($fieldName, 'simID') === 0 && $table !== 'simcard_tbl') {
            $html .= getSimCardDropdown($conn, $currentValue);
        } elseif (strpos($fieldName, 'serviceID') === 0 && $table !== 'service_tbl') {
            $html .= getServiceDropdown($conn, $currentValue);
        }
        elseif (strpos($fieldType, 'enum') !== false) {
            preg_match("/enum\((.*)\)/", $fieldType, $matches);
            $optionsStr = rtrim(ltrim($matches[1], "'"), "'");
            $options = explode("','", $optionsStr);
            $html .= '<select class="form-select" id="' . $fieldName . '" name="' . $fieldName . '" ' . $required . '>';
            foreach ($options as $option) {
                $selected = ($currentValue === $option) ? 'selected' : '';
                $html .= '<option value="' . htmlspecialchars($option) . '" ' . $selected . '>' . ucfirst($option) . '</option>';
            }
            $html .= '</select>';
        } 
        elseif (strpos($fieldType, 'date') !== false) {
            $html .= '<input type="date" class="form-control" id="' . $fieldName . '" name="' . $fieldName . '" value="' . htmlspecialchars($currentValue) . '" ' . $required . '>';
        } 
        else {
            $inputType = (strpos($fieldName, 'password') !== false) ? 'password' : 'text';
            $html .= '<input type="' . $inputType . '" class="form-control" id="' . $fieldName . '" name="' . $fieldName . '" value="' . htmlspecialchars($currentValue) . '" ' . $required . '>';
        }
        
        $html .= '</div>';
    }
    
    $html .= '</form>';
    
    echo $html;
}

function getClientDropdown($conn, $selectedValue = '') {
    $html = '<select class="form-select" name="clientID" required><option value="">Select Client</option>';
    $result = $conn->query("SELECT clientID, clientName FROM client_tbl ORDER BY clientName");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $selected = ($selectedValue == $row['clientID']) ? 'selected' : '';
            $html .= '<option value="' . $row['clientID'] . '" ' . $selected . '>' . $row['clientName'] . '</option>';
        }
    }
    $html .= '</select>';
    return $html;
}

function getDeviceDropdown($conn, $selectedValue = '') {
    $html = '<select class="form-select" name="dID" required><option value="">Select Device</option>';
    $result = $conn->query("SELECT dID FROM device_tbl ORDER BY dID");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $selected = ($selectedValue == $row['dID']) ? 'selected' : '';
            $html .= '<option value="' . $row['dID'] . '" ' . $selected . '>' . $row['dID'] . '</option>';
        }
    }
    $html .= '</select>';
    return $html;
}

function getSimCardDropdown($conn, $selectedValue = '') {
    $html = '<select class="form-select" name="simID" required><option value="">Select SIM Card</option>';
    $result = $conn->query("SELECT simID FROM simcard_tbl ORDER BY simID");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $selected = ($selectedValue == $row['simID']) ? 'selected' : '';
            $html .= '<option value="' . $row['simID'] . '" ' . $selected . '>' . $row['simID'] . '</option>';
        }
    }
    $html .= '</select>';
    return $html;
}

function getServiceDropdown($conn, $selectedValue = '') {
    $html = '<select class="form-select" name="serviceID" required><option value="">Select Service</option>';
    $result = $conn->query("SELECT serviceID, serviceName FROM service_tbl ORDER BY serviceName");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $selected = ($selectedValue == $row['serviceID']) ? 'selected' : '';
            $html .= '<option value="' . $row['serviceID'] . '" ' . $selected . '>' . $row['serviceName'] . '</option>';
        }
    }
    $html .= '</select>';
    return $html;
}

function addRecord($conn, $table) {
    $data = $_POST;
    $columns = [];
    $values = [];
    $placeholders = [];
    
    $fields = getTableFields($conn, $table);
    $fieldMap = [];
    foreach($fields as $field) {
        $fieldMap[$field['Field']] = $field;
    }
    
    foreach ($data as $key => $value) {
        if (!isset($fieldMap[$key])) continue;
        if (strpos($fieldMap[$key]['Extra'], 'auto_increment') !== false) continue;
        
        $columns[] = "`$key`";
        $values[] = $value;
        $placeholders[] = '?';
    }
    
    if (empty($columns)) {
        echo json_encode(['success' => false, 'message' => 'No valid data provided.']);
        return;
    }
    
    $sql = "INSERT INTO `$table` (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ")";
    $stmt = $conn->prepare($sql);
    
    $types = '';
    foreach ($columns as $index => $column) {
        $cleanColumn = trim($column, '`');
        $type = $fieldMap[$cleanColumn]['Type'];
        if (strpos($type, 'int') !== false) $types .= 'i';
        elseif (strpos($type, 'double') !== false || strpos($type, 'float') !== false) $types .= 'd';
        else $types .= 's';
    }
    
    $stmt->bind_param($types, ...$values);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error adding record: ' . $stmt->error]);
    }
}

function updateRecord($conn, $table, $id) {
    $data = $_POST;
    $updates = [];
    $values = [];
    
    $fields = getTableFields($conn, $table);
    $fieldMap = [];
    foreach($fields as $field) {
        $fieldMap[$field['Field']] = $field;
    }
    
    $primaryKey = getPrimaryKey($conn, $table);
    
    foreach ($data as $key => $value) {
        if (!isset($fieldMap[$key]) || $key === $primaryKey) continue;
        
        $updates[] = "`$key` = ?";
        $values[] = $value;
    }
    
    if (empty($updates)) {
        echo json_encode(['success' => false, 'message' => 'No data to update.']);
        return;
    }

    $sql = "UPDATE `$table` SET " . implode(', ', $updates) . " WHERE `$primaryKey` = ?";
    $values[] = $id;
    
    $stmt = $conn->prepare($sql);
    
    $types = '';
    foreach ($updates as $update) {
        $column = trim(explode('=', $update)[0]);
        $cleanColumn = trim($column, '`');
        $type = $fieldMap[$cleanColumn]['Type'];
        if (strpos($type, 'int') !== false) $types .= 'i';
        elseif (strpos($type, 'double') !== false || strpos($type, 'float') !== false) $types .= 'd';
        else $types .= 's';
    }
    
    $pkType = $fieldMap[$primaryKey]['Type'];
    if (strpos($pkType, 'int') !== false) $types .= 'i';
    elseif (strpos($pkType, 'double') !== false || strpos($pkType, 'float') !== false) $types .= 'd';
    else $types .= 's';
    
    $stmt->bind_param($types, ...$values);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error updating record: ' . $stmt->error]);
    }
}

function deleteRecord($conn, $table, $id) {
    $primaryKey = getPrimaryKey($conn, $table);
    
    $sql = "DELETE FROM `$table` WHERE `$primaryKey` = ?";
    $stmt = $conn->prepare($sql);
    
    $pkType = getTableFields($conn, $table);
    $pkField = array_values(array_filter($pkType, function($field) use ($primaryKey) {
        return $field['Field'] === $primaryKey;
    }));
    $type = 's';
    if (!empty($pkField)) {
        $fieldType = $pkField[0]['Type'];
        if (strpos($fieldType, 'int') !== false) $type = 'i';
        elseif (strpos($fieldType, 'double') !== false || strpos($fieldType, 'float') !== false) $type = 'd';
    }

    $stmt->bind_param($type, $id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error deleting record: ' . $stmt->error]);
    }
}

function getChartDataAPI($conn) {
    $data = [];
    $sql = "SELECT status, COUNT(*) as count FROM device_tbl GROUP BY status";
    $result = $conn->query($sql);

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $data[$row['status']] = (int)$row['count'];
        }
        echo json_encode($data);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error fetching chart data.']);
    }
}

function getFleetView($conn, $page, $limit, $search) {
    $page = (int)$page;
    $limit = (int)$limit;
    $search = mysqli_real_escape_string($conn, $search);
    
    $offset = ($page - 1) * $limit;
    
    $whereClause = '';
    if (!empty($search)) {
        $searchFields = ["`clientID`","`dID`","`simID`","`provider`","`companyName`","`plateNo`","`cost`","`installDate`","`comment`"];
        $searchConditions = array_map(function($field) use ($search) {
            return "$field LIKE '%$search%'";
        }, $searchFields);
        $whereClause = " WHERE " . implode(' OR ', $searchConditions);
    }

    $countSql = "SELECT COUNT(*) as count FROM `fleet_view` $whereClause";
    $countResult = $conn->query($countSql);
    $totalRecords = $countResult ? $countResult->fetch_assoc()['count'] : 0;
    
    $sql = "SELECT * FROM `fleet_view` $whereClause LIMIT $limit OFFSET $offset";
    $result = $conn->query($sql);
    
    if (!$result) {
        echo json_encode(['success' => false, 'message' => 'Error loading fleet view: ' . $conn->error]);
        return;
    }
    
    $columns = [];
    $columnNames = [];
    if ($result->num_rows > 0) {
        $fields = $result->fetch_fields();
        foreach ($fields as $field) {
            $columns[] = ucwords(str_replace('_', ' ', $field->name));
            $columnNames[] = $field->name;
        }
    }
    
    $records = [];
    while ($row = $result->fetch_assoc()) {
        $records[] = $row;
    }
    
    $responseData = [
        'success' => true,
        'records' => $records,
        'columns' => $columns,
        'columnNames' => $columnNames,
        'primaryKey' => 'No',
        'displayName' => 'Fleet View',
        'totalRecords' => $totalRecords,
        'currentPage' => $page,
        'limit' => $limit,
        'totalPages' => ceil($totalRecords / $limit),
        'searchQuery' => $search,
        'isView' => true
    ];
    
    echo json_encode($responseData);
}

function getChartData() {
    global $dbHost, $dbUser, $dbPass, $dbName;
    
    $conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
    
    if ($conn->connect_error) {
        http_response_code(500);
        echo json_encode(['error' => 'Connection failed: ' . $conn->connect_error]);
        exit();
    }
    
    $response = [
        'totalVehicles' => ['total_vehicles' => 0],
        'totalClients' => ['total_clients' => 0],
        'vehiclesProvider' => [],
        'vehiclesRegion' => [],
        'vehiclesByClient' => [],
        'costByProvider' => []
    ];
    
    $safeQuery = function($sql) use ($conn) {
        $result = $conn->query($sql);
        if (!$result) {
            
            return false;
        }
        return $result;
    };
    
    
    if ($result = $safeQuery("SELECT COUNT(*) AS total_vehicles FROM fleet_tbl")) {
        $response['totalVehicles'] = $result->fetch_assoc();
    }
    
    
    if ($result = $safeQuery("SELECT COUNT(DISTINCT clientID) AS total_clients FROM client_tbl")) {
        $response['totalClients'] = $result->fetch_assoc();
    }
    
    
    if ($result = $safeQuery("SELECT T2.provider, COUNT(T1.No) AS vehicle_count FROM fleet_tbl AS T1 JOIN simcard_tbl AS T2 ON T1.simID = T2.simID GROUP BY T2.provider")) {
        while ($row = $result->fetch_assoc()) {
            $response['vehiclesProvider'][] = $row;
        }
    }
    
    
    if ($result = $safeQuery("SELECT T2.region, COUNT(T1.No) AS vehicle_count FROM fleet_tbl AS T1 JOIN client_tbl AS T2 ON T1.clientID = T2.clientID GROUP BY T2.region")) {
        while ($row = $result->fetch_assoc()) {
            $response['vehiclesRegion'][] = $row;
        }
    }
    
    
    if ($result = $safeQuery("SELECT T2.clientName, COUNT(T1.No) AS vehicle_count FROM fleet_tbl AS T1 JOIN client_tbl AS T2 ON T1.clientID = T2.clientID GROUP BY T2.clientName ORDER BY vehicle_count DESC")) {
        while ($row = $result->fetch_assoc()) {
            $response['vehiclesByClient'][] = $row;
        }
    }
    
    if ($result = $safeQuery("SELECT provider, COUNT(*) as sim_count FROM simcard_tbl GROUP BY provider")) {
        while ($row = $result->fetch_assoc()) {
            $cost = ($row['provider'] == 'A') ? $row['sim_count'] * 1000 : $row['sim_count'] * 1300;
            $response['costByProvider'][] = [
                'provider' => $row['provider'],
                'total_cost' => $cost,
                'sim_count' => $row['sim_count']
            ];
        }
    }
    
    $conn->close();
    
    echo json_encode($response);
}


function getAllData() {
    global $dbHost, $dbUser, $dbPass, $dbName;
    
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    error_reporting(E_ALL);
    
    header('Cache-Control: no-cache, must-revalidate');
    
    if (!isset($dbHost, $dbUser, $dbPass, $dbName)) {
        http_response_code(500);
        die(json_encode(['error' => 'Database configuration incomplete']));
    }
    
    $allowedTables = [
        'client_tbl' => ['clientID', 'clientName', 'companyName', 'phoneNo', 'email', 'region'],
        'fleet_tbl' => ['No', 'clientID', 'dID', 'simID', 'plateNo', 'cost', 'installDate', 'comment']
    ];
    
    try {
        if (empty($_GET['table'])) {
            throw new Exception('No table specified');
        }
    
        $tableName = $_GET['table'];
        
        if (!array_key_exists($tableName, $allowedTables)) {
            throw new Exception('Invalid table name');
        }
        
        $columns = '*';
        if (!empty($_GET['columns'])) {
            $requestedColumns = explode(',', $_GET['columns']);
            $validColumns = array_intersect($requestedColumns, $allowedTables[$tableName]);
            
            if (!empty($validColumns)) {
                $columns = '`' . implode('`,`', $validColumns) . '`';
            }
        }
        
        $conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
    
        if ($conn->connect_error) {
            throw new Exception('Database connection failed');
        }
        
        $sql = "SELECT $columns FROM `$tableName`";
        $result = $conn->query($sql);
    
        if (!$result) {
            throw new Exception('Query failed: ' . $conn->error);
        }
        
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    
        $conn->close();
        
        echo json_encode($data);
        exit;
    
    } catch (Exception $e) {
        http_response_code(500);
        die(json_encode(['error' => $e->getMessage()]));
    }
}
?>
